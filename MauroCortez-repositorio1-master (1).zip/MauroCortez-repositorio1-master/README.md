# Mauro Cortez
Aluno do SENAI
1º Semestre Redes - Tarde
